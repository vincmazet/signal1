# Plain Latex Book

A minimal book template that uses vanilla LaTeX commands and environments

![](thumbnail.png)

- Author: Rowan Cockett
- License: CC-BY-4.0
